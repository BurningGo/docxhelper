from .table import *


def joke():
    print("successful install????")

