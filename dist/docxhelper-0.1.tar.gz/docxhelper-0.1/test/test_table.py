import unittest

from docxhelper import table

class TestTableModule(unittest.TestCase):
    def test_AlignAllCellsVerticallyCenter(self):
        print("Yes, you did it!")

if __name__ == '__main__':
    unittest.main()


